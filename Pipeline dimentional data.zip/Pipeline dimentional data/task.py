import os
import subprocess
from utils import read_sql_script, execute_sql_script, parse_db_config, create_connection_string
from time import sleep


def create_tables(db_config, schema_name):

    try:
        create_table_script = read_sql_script('your exact path, did not write mine here')
        create_table_script_2 = read_sql_script('same')
        create_table_script_3 = read_sql_script('same')

        connection_string = create_connection_string(db_config)

        execute_sql_script(connection_string, create_table_script)
        execute_sql_script(connection_string, create_table_script_2)
        execute_sql_script(connection_string, create_table_script_3)

        return {'success': True}
    except Exception as e:
        print(f"Error creating tables: {e}")
        return {'success': False}


def ingest_data(db_config, schema_name, start_date, end_date, table_name):
    try:
        sql_script = read_sql_script(f'path_to_update_dim_{table_name}.sql')

        connection_string = create_connection_string(db_config)

        execute_sql_script(connection_string, sql_script)

        return {'success': True}
    except Exception as e:
        print(f"Error ingesting data into {table_name}: {e}")
        return {'success': False}


def ingest_error_data(db_config, schema_name, start_date, end_date):
    try:
        sql_script = read_sql_script('path_to_update_fact_error.sql')

        connection_string = create_connection_string(db_config)

        execute_sql_script(connection_string, sql_script)

        return {'success': True}
    except Exception as e:
        print(f"Error ingesting data into fact_error table: {e}")
        return {'success': False}


def run_pipeline():
    db_config = parse_db_config('path_to_config_file.cfg')
    schema_name = 'dbo'  # Example schema name
    start_date = '2025-01-01'
    end_date = '2025-12-31'

    table_creation_result = create_tables(db_config, schema_name)
    if not table_creation_result['success']:
        print("Table creation failed. Exiting pipeline.")
        return

    for table_name in ['Categories', 'Customers', 'Employees', 'Products', 'Region', 'Shippers', 'Suppliers', 'Territories']:
        ingestion_result = ingest_data(db_config, schema_name, start_date, end_date, table_name)
        if not ingestion_result['success']:
            print(f"Ingestion into {table_name} failed. Exiting pipeline.")
            return
        print(f"Ingestion into {table_name} succeeded.")
        sleep(1)

    error_data_result = ingest_error_data(db_config, schema_name, start_date, end_date)
    if error_data_result['success']:
        print("Error data ingestion completed successfully.")
    else:
        print("Error data ingestion failed.")


if __name__ == "__main__":
    run_pipeline()
