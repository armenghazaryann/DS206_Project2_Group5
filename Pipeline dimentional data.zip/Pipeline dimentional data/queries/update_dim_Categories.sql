-- update_dim_Categories.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Categories'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Categories';

-- Insert new or updated data from stg_Categories to DimCategories
MERGE INTO dbo.DimCategories AS target
USING dbo.stg_Categories AS source
ON target.CategoryID = source.CategoryID
WHEN MATCHED AND (
    target.CategoryName != source.CategoryName OR
    target.Description != source.Description
) THEN
    UPDATE SET
        target.CategoryName = source.CategoryName,
        target.Description = source.Description
WHEN NOT MATCHED BY TARGET THEN
    INSERT (CategoryID, CategoryName, Description, CreatedAt, StagingRawID)
    VALUES (source.CategoryID, source.CategoryName, source.Description, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimCategories table
UPDATE dbo.DimCategories
SET StagingRawID = @StagingRawID
WHERE CategoryID IN (SELECT CategoryID FROM dbo.stg_Categories WHERE OrderDate BETWEEN @StartDate AND @EndDate);
