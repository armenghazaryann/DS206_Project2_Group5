-- update_fact_error.sql

DECLARE @DatabaseName NVARCHAR(255);
DECLARE @SchemaName NVARCHAR(255);
DECLARE @TableName NVARCHAR(255);
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;
DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;

-- Set the parameters (These will be passed when the script is called)
SET @DatabaseName = 'ORDER_DDS';  -- Replace with actual database name if needed
SET @SchemaName = 'dbo';  -- Replace with actual schema name if needed
SET @TableName = 'FactOrders';  -- Replace with the actual fact table name
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for the respective staging raw table
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Orders';  -- Replace with the staging raw table name

-- Insert rows with invalid or missing natural keys into the fact_error table
INSERT INTO dbo.FactErrorTable (OrderID, CustomerID, EmployeeID, ErrorMessage, StagingRawID, CreatedAt)
SELECT source.OrderID,
       source.CustomerID,
       source.EmployeeID,
       'Missing/Invalid Natural Key',  -- Error message for the problematic row
       @StagingRawID,
       GETDATE()
FROM dbo.stg_Orders AS source
WHERE source.OrderDate BETWEEN @StartDate AND @EndDate
AND (
    source.CustomerID IS NULL OR 
    NOT EXISTS (SELECT 1 FROM dbo.DimCustomers WHERE CustomerID = source.CustomerID) OR
    source.EmployeeID IS NULL OR
    NOT EXISTS (SELECT 1 FROM dbo.DimEmployees WHERE EmployeeID = source.EmployeeID)
);

-- Optionally, log other errors that might happen during the ingestion
-- For example, you can add error handling for other foreign key checks or missing fields
