-- update_fact.sql

DECLARE @DatabaseName NVARCHAR(255);
DECLARE @SchemaName NVARCHAR(255);
DECLARE @TableName NVARCHAR(255);
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;
DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;

-- Set the parameters (These will be passed when the script is called)
SET @DatabaseName = 'ORDER_DDS';  -- Replace with actual database name if needed
SET @SchemaName = 'dbo';  -- Replace with actual schema name if needed
SET @TableName = 'FactOrders';  -- Replace with the actual fact table name
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for the respective staging raw table
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Orders';  -- Replace with the staging raw table name

-- MERGE Statement to Insert or Update FactOrders
MERGE INTO dbo.FactOrders AS target
USING dbo.stg_Orders AS source
ON target.OrderID = source.OrderID
WHEN MATCHED AND (
    target.ShippedDate != source.ShippedDate OR
    target.Freight != source.Freight
) THEN
    UPDATE SET
        target.ShippedDate = source.ShippedDate,
        target.Freight = source.Freight,
        target.ShipName = source.ShipName,
        target.ShipCity = source.ShipCity,
        target.ShipCountry = source.ShipCountry,
        target.CreatedAt = GETDATE()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (OrderID, CustomerSK, EmployeeSK, OrderDate, ShippedDate, Freight, ShipName, ShipCity, ShipCountry, CreatedAt, StagingRawID)
    VALUES (source.OrderID, 
            (SELECT CustomerSK FROM dbo.DimCustomers WHERE CustomerID = source.CustomerID),  -- Lookup the surrogate key
            (SELECT EmployeeSK FROM dbo.DimEmployees WHERE EmployeeID = source.EmployeeID),  -- Lookup the surrogate key
            source.OrderDate, source.ShippedDate, source.Freight, source.ShipName, source.ShipCity, source.ShipCountry, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the FactOrders table
UPDATE dbo.FactOrders
SET StagingRawID = @StagingRawID
WHERE OrderID IN (SELECT OrderID FROM dbo.stg_Orders WHERE OrderDate BETWEEN @StartDate AND @EndDate);
