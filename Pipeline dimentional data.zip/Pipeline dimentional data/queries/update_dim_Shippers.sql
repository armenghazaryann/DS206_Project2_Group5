-- update_dim_Shippers.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Shippers'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Shippers';

-- Insert new or updated data from stg_Shippers to DimShippers
MERGE INTO dbo.DimShippers AS target
USING dbo.stg_Shippers AS source
ON target.ShipperID = source.ShipperID
WHEN MATCHED AND (
    target.CompanyName != source.CompanyName OR
    target.Phone != source.Phone
) THEN
    UPDATE SET
        target.CompanyName = source.CompanyName,
        target.Phone = source.Phone,
        target.StartDate = GETDATE(),
        target.IsCurrent = 1,
        target.EndDate = NULL
WHEN NOT MATCHED BY TARGET THEN
    INSERT (ShipperID, CompanyName, Phone, CreatedAt, StagingRawID)
    VALUES (source.ShipperID, source.CompanyName, source.Phone, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimShippers table
UPDATE dbo.DimShippers
SET StagingRawID = @StagingRawID
WHERE ShipperID IN (SELECT ShipperID FROM dbo.stg_Shippers WHERE OrderDate BETWEEN @StartDate AND @EndDate);
