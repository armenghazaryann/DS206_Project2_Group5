-- update_dim_Products.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Products'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Products';

-- Insert new or updated data from stg_Products to DimProducts
MERGE INTO dbo.DimProducts AS target
USING dbo.stg_Products AS source
ON target.ProductID = source.ProductID
WHEN MATCHED AND (
    target.ProductName != source.ProductName OR
    target.SupplierID != source.SupplierID
) THEN
    UPDATE SET
        target.ProductName = source.ProductName,
        target.SupplierID = source.SupplierID,
        target.StartDate = GETDATE(),
        target.IsCurrent = 1,
        target.EndDate = NULL
WHEN NOT MATCHED BY TARGET THEN
    INSERT (ProductID, ProductName, SupplierID, CreatedAt, StagingRawID)
    VALUES (source.ProductID, source.ProductName, source.SupplierID, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimProducts table
UPDATE dbo.DimProducts
SET StagingRawID = @StagingRawID
WHERE ProductID IN (SELECT ProductID FROM dbo.stg_Products WHERE OrderDate BETWEEN @StartDate AND @EndDate);
