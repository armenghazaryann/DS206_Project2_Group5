-- update_dim_Region.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Region'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Region';

-- Insert new or updated data from stg_Region to DimRegion
MERGE INTO dbo.DimRegion AS target
USING dbo.stg_Region AS source
ON target.RegionID = source.RegionID
WHEN MATCHED AND (
    target.RegionDescription != source.RegionDescription
) THEN
    UPDATE SET
        target.RegionDescription = source.RegionDescription,
        target.StartDate = GETDATE(),
        target.IsCurrent = 1,
        target.EndDate = NULL
WHEN NOT MATCHED BY TARGET THEN
    INSERT (RegionID, RegionDescription, CreatedAt, StagingRawID)
    VALUES (source.RegionID, source.RegionDescription, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimRegion table
UPDATE dbo.DimRegion
SET StagingRawID = @StagingRawID
WHERE RegionID IN (SELECT RegionID FROM dbo.stg_Region WHERE OrderDate BETWEEN @StartDate AND @EndDate);
