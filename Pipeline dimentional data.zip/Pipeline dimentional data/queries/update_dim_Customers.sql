-- update_dim_Customers.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Customers'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Customers';

-- Insert new or updated data from stg_Customers to DimCustomers
MERGE INTO dbo.DimCustomers AS target
USING dbo.stg_Customers AS source
ON target.CustomerID = source.CustomerID
WHEN MATCHED AND (
    target.CompanyName != source.CompanyName OR
    target.ContactName != source.ContactName
) THEN
    UPDATE SET
        target.CompanyName = source.CompanyName,
        target.ContactName = source.ContactName
WHEN NOT MATCHED BY TARGET THEN
    INSERT (CustomerID, CompanyName, ContactName, CreatedAt, StagingRawID)
    VALUES (source.CustomerID, source.CompanyName, source.ContactName, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimCustomers table
UPDATE dbo.DimCustomers
SET StagingRawID = @StagingRawID
WHERE CustomerID IN (SELECT CustomerID FROM dbo.stg_Customers WHERE OrderDate BETWEEN @StartDate AND @EndDate);
