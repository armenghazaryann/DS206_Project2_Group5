-- update_dim_Suppliers.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Suppliers'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Suppliers';

-- Insert new or updated data from stg_Suppliers to DimSuppliers
MERGE INTO dbo.DimSuppliers AS target
USING dbo.stg_Suppliers AS source
ON target.SupplierID = source.SupplierID
WHEN MATCHED AND (
    target.CompanyName != source.CompanyName OR
    target.ContactName != source.ContactName
) THEN
    UPDATE SET
        target.CompanyName = source.CompanyName,
        target.ContactName = source.ContactName,
        target.StartDate = GETDATE(),
        target.IsCurrent = 1,
        target.EndDate = NULL
WHEN NOT MATCHED BY TARGET THEN
    INSERT (SupplierID, CompanyName, ContactName, CreatedAt, StagingRawID)
    VALUES (source.SupplierID, source.CompanyName, source.ContactName, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimSuppliers table
UPDATE dbo.DimSuppliers
SET StagingRawID = @StagingRawID
WHERE SupplierID IN (SELECT SupplierID FROM dbo.stg_Suppliers WHERE OrderDate BETWEEN @StartDate AND @EndDate);
