-- update_dim_Employees.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Employees'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Employees';

-- Insert new or updated data from stg_Employees to DimEmployees
MERGE INTO dbo.DimEmployees AS target
USING dbo.stg_Employees AS source
ON target.EmployeeID = source.EmployeeID
WHEN MATCHED AND (
    target.LastName != source.LastName OR
    target.FirstName != source.FirstName
) THEN
    UPDATE SET
        target.LastName = source.LastName,
        target.FirstName = source.FirstName
WHEN NOT MATCHED BY TARGET THEN
    INSERT (EmployeeID, LastName, FirstName, CreatedAt, StagingRawID)
    VALUES (source.EmployeeID, source.LastName, source.FirstName, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimEmployees table
UPDATE dbo.DimEmployees
SET StagingRawID = @StagingRawID
WHERE EmployeeID IN (SELECT EmployeeID FROM dbo.stg_Employees WHERE OrderDate BETWEEN @StartDate AND @EndDate);
