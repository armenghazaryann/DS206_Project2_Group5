-- update_dim_Territories.sql

DECLARE @SOR_SK INT;
DECLARE @StagingRawID INT;
DECLARE @StartDate DATETIME;
DECLARE @EndDate DATETIME;

-- Set the parameters (These will be passed when the script is called)
SET @StartDate = '2025-01-01';  -- Replace with actual start date
SET @EndDate = '2025-12-31';  -- Replace with actual end date

-- Get the SOR_SK from Dim_SOR for 'stg_Territories'
SELECT @SOR_SK = SOR_SK, @StagingRawID = StagingRawID 
FROM dbo.Dim_SOR
WHERE StagingRawTableName = 'stg_Territories';

-- Insert new or updated data from stg_Territories to DimTerritories
MERGE INTO dbo.DimTerritories AS target
USING dbo.stg_Territories AS source
ON target.TerritoryID = source.TerritoryID
WHEN MATCHED AND (
    target.TerritoryDescription != source.TerritoryDescription
) THEN
    UPDATE SET
        target.TerritoryDescription = source.TerritoryDescription,
        target.StartDate = GETDATE(),
        target.IsCurrent = 1,
        target.EndDate = NULL
WHEN NOT MATCHED BY TARGET THEN
    INSERT (TerritoryID, TerritoryDescription, CreatedAt, StagingRawID)
    VALUES (source.TerritoryID, source.TerritoryDescription, GETDATE(), @StagingRawID);

-- Update the staging raw ID in the DimTerritories table
UPDATE dbo.DimTerritories
SET StagingRawID = @StagingRawID
WHERE TerritoryID IN (SELECT TerritoryID FROM dbo.stg_Territories WHERE OrderDate BETWEEN @StartDate AND @EndDate);
