import os
import configparser
import pyodbc
import logging

def read_sql_script(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The SQL script file at {file_path} does not exist.")
    with open(file_path, 'r') as file:
        return file.read()


def parse_db_config(config_file):
    config = configparser.ConfigParser()
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"The config file at {config_file} does not exist.")
    config.read(config_file)

    db_config = {}
    if 'sqlserver' in config:
        db_config['server'] = config['sqlserver'].get('server')
        db_config['database'] = config['sqlserver'].get('database')
        db_config['user'] = config['sqlserver'].get('user')
        db_config['password'] = config['sqlserver'].get('password')
        db_config['driver'] = config['sqlserver'].get('driver')
    else:
        raise ValueError("The 'sqlserver' section is missing from the config file.")

    return db_config


def create_connection_string(db_config):
    return f"DRIVER={db_config['driver']};SERVER={db_config['server']};DATABASE={db_config['database']};UID={db_config['user']};PWD={db_config['password']}"


def execute_sql_script(connection_string, sql_script):
    try:
        connection = pyodbc.connect(connection_string)
        cursor = connection.cursor()
        cursor.execute(sql_script)
        connection.commit()
        cursor.close()
        connection.close()
    except Exception as e:
        raise RuntimeError(f"Error executing SQL script: {e}")

def setup_logging(log_file='app.log'):
    logging.basicConfig(filename=log_file, level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
    return logging.getLogger()


def log_message(message, level='INFO'):
    logger = setup_logging()
    if level == 'DEBUG':
        logger.debug(message)
    elif level == 'INFO':
        logger.info(message)
    elif level == 'WARNING':
        logger.warning(message)
    elif level == 'ERROR':
        logger.error(message)
    elif level == 'CRITICAL':
        logger.critical(message)
    else:
        logger.info(message)
